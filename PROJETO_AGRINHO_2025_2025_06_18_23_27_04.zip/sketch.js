let currentSlide = 0; // Controla qual slide está ativo
let buttonNext; // Botão para avançar
let buttonBack; // Botão para retroceder

// Variáveis para ilustração (exemplo)
let farmImage;
let pesticideBottle;
let bugIcon;

function preload() {
  // Opcional: Carregue imagens e fontes aqui se for usar arquivos externos.
  // Por exemplo:
  // farmImage = loadImage('assets/campo.png');
  // pesticideBottle = loadImage('assets/frasco_agrotoxico.png');
  // bugIcon = loadImage('assets/inseto.png');
}

function setup() {
  createCanvas(900, 600); // Tamanho da apresentação
  textAlign(CENTER, CENTER); // Alinhamento padrão do texto
  rectMode(CENTER); // Desenha retângulos do centro para facilitar o posicionamento

  // --- Criação dos Botões de Navegação ---
  // Botão "Próximo"
  buttonNext = {
    x: width - 80,
    y: height - 40,
    width: 120,
    height: 50,
    text: "Próximo"
  };

  // Botão "Voltar" (aparece a partir do segundo slide)
  buttonBack = {
    x: 80,
    y: height - 40,
    width: 120,
    height: 50,
    text: "Voltar"
  };
}

function draw() {
  background(240, 255, 240); // Cor de fundo suave (verde claro)

  // Chama a função do slide atual
  if (currentSlide === 0) {
    drawSlide0_Intro();
  } else if (currentSlide === 1) {
    drawSlide1_OQueSao();
  } else if (currentSlide === 2) {
    drawSlide2_DiferentesLavouras();
  } else if (currentSlide === 3) {
    drawSlide3_ImpactosDesafios();
  } else if (currentSlide === 4) {
    drawSlide4_Alternativas();
  } else if (currentSlide === 5) {
    drawSlide5_Conclusao();
  }

  // Desenha os botões de navegação
  drawNavigationButtons();
}

// --- Funções de Desenho para Cada Slide ---

function drawSlide0_Intro() {
  // Slide 1: Introdução - O Campo e Seus Desafios
  fill(50, 100, 50); // Cor para títulos
  textSize(40);
  text("O Campo em Nossas Mãos:", width / 2, height / 4 - 30);
  text("Desafios e Soluções", width / 2, height / 4 + 30);

  fill(80, 80, 80); // Cor para texto descritivo
  textSize(20);
  text("Como protegemos nossas lavouras para garantir alimentos de qualidade para todos?", width / 2, height / 2);

  // Ilustração de Campo (exemplo simplificado)
  fill(120, 200, 120); // Verde grama
  rect(width / 2, height * 0.75, width * 0.8, height * 0.3);

  fill(180, 100, 50); // Marrom terra
  rect(width / 2, height * 0.75 + 50, width * 0.7, height * 0.1);

  // Pequenas plantas estilizadas
  for (let i = 0; i < 5; i++) {
    fill(50, 150, 50);
    ellipse(width * 0.2 + i * 120, height * 0.7, 30, 60);
    fill(180, 80, 20); // Cor de "praga"
    ellipse(width * 0.2 + i * 120 + 10, height * 0.7 - 20, 10, 10);
  }
}

function drawSlide1_OQueSao() {
  // Slide 2: O Que São os Agrotóxicos?
  fill(50, 100, 50);
  textSize(36);
  text("Agrotóxicos: O Que São e Para Que Servem?", width / 2, 70);

  fill(80, 80, 80);
  textSize(18);
  text("Produtos utilizados para proteger as plantas de pragas, doenças e ervas daninhas,", width / 2, 130);
  text("garantindo a produtividade das lavouras.", width / 2, 155);

  // Ilustração de frasco de agrotóxico e alvos (exemplo)
  fill(100, 100, 100); // Corpo do frasco
  rect(width / 2 - 100, height / 2 + 50, 60, 100, 10); // Arredondado

  fill(70, 70, 70); // Tampa
  rect(width / 2 - 100, height / 2 - 5, 40, 20, 5);

  fill(255, 0, 0, 150); // Símbolo de perigo (vermelho transparente)
  triangle(width / 2 - 130, height / 2 + 120, width / 2 - 70, height / 2 + 120, width / 2 - 100, height / 2 + 70);

  // Ícones de pragas
  fill(0);
  textSize(16);
  text("Insetos", width / 2 + 100, height / 2 - 50);
  text("Fungos", width / 2 + 100, height / 2 + 20);
  text("Ervas Daninhas", width / 2 + 100, height / 2 + 90);

  fill(150, 50, 0); // Cor do inseto
  ellipse(width / 2 + 100, height / 2 - 80, 20, 20); // Inseto
  line(width / 2 + 90, height / 2 - 80, width / 2 + 110, height / 2 - 80); // Asas simples

  fill(80, 80, 180); // Cor do fungo
  arc(width / 2 + 100, height / 2 + 10, 30, 30, PI, TWO_PI); // Chapéu de cogumelo
  rect(width / 2 + 100, height / 2 + 25, 5, 15); // Caule

  fill(50, 150, 50); // Cor da erva
  triangle(width / 2 + 100, height / 2 + 60, width / 2 + 90, height / 2 + 90, width / 2 + 110, height / 2 + 90);
}

function drawSlide2_DiferentesLavouras() {
  // Slide 3: Agrotóxicos em Diferentes Lavouras
  fill(50, 100, 50);
  textSize(36);
  text("Cada Lavoura, Uma Necessidade Diferente", width / 2, 70);

  fill(80, 80, 80);
  textSize(18);
  text("O tipo de lavoura e as pragas específicas determinam o uso de agrotóxicos.", width / 2, 120);

  // Exemplo de cenários de lavoura (simplificado)
  // Lavoura de Milho/Soja
  fill(180, 150, 50);
  rect(width / 4, height / 2 - 30, 180, 100, 5);
  fill(0);
  textSize(16);
  text("Grãos (Milho/Soja)", width / 4, height / 2 + 40);
  text("Foco: Produtividade\n(Herbicidas, Inseticidas)", width / 4, height / 2 + 80);

  // Horta / Hortaliças
  fill(120, 180, 120);
  rect(width / 2, height / 2 - 30, 180, 100, 5);
  fill(0);
  text("Hortaliças", width / 2, height / 2 + 40);
  text("Foco: Aparência\n(Fungicidas, Inseticidas)", width / 2, height / 2 + 80);

  // Pomar / Frutas
  fill(200, 120, 80);
  rect(width * 3 / 4, height / 2 - 30, 180, 100, 5);
  fill(0);
  text("Frutas (Pomar)", width * 3 / 4, height / 2 + 40);
  text("Foco: Sanidade\n(Fungicidas, Inseticidas)", width * 3 / 4, height / 2 + 80);

  // Opcional: Adicionar pequenos ícones ou símbolos para cada tipo de praga/produto
}


function drawSlide3_ImpactosDesafios() {
  // Slide 4: Impactos e Desafios do Uso de Agrotóxicos
  fill(50, 100, 50);
  textSize(36);
  text("Os Dois Lados da Moeda:", width / 2, 70);
  text("Benefícios e Preocupações", width / 2, 110);

  // Coluna de Benefícios (lado esquerdo)
  fill(100, 180, 100); // Verde claro para o lado positivo
  rect(width / 4, height / 2 + 50, width / 2 - 50, height / 2 - 120, 10);
  fill(0);
  textSize(20);
  text("Benefícios", width / 4, height / 2 - 100);
  textSize(16);
  text("• Aumento da produção", width / 4, height / 2 - 40);
  text("• Controle eficaz de pragas", width / 4, height / 2 - 10);
  text("• Redução de perdas na lavoura", width / 4, height / 2 + 20);

  // Coluna de Preocupações (lado direito)
  fill(220, 150, 150); // Vermelho claro para o lado negativo
  rect(width * 3 / 4, height / 2 + 50, width / 2 - 50, height / 2 - 120, 10);
  fill(0);
  textSize(20);
  text("Preocupações", width * 3 / 4, height / 2 - 100);
  textSize(16);
  text("• Impacto na saúde humana", width * 3 / 4, height / 2 - 40);
  text("• Contaminação do solo e água", width * 3 / 4, height / 2 - 10);
  text("• Perda de biodiversidade", width * 3 / 4, height / 2 + 20);

  // Ilustrações simples de cada lado
  fill(50, 200, 50); // Planta saudável
  triangle(width / 4 - 80, height / 2 + 100, width / 4 - 50, height / 2 + 130, width / 4 - 20, height / 2 + 100);
  rect(width / 4 - 50, height / 2 + 130, 5, 20);

  fill(0, 0, 255, 100); // Gota de água poluída
  ellipse(width * 3 / 4 + 80, height / 2 + 100, 30, 40);
  fill(255);
  textSize(12);
  text("X", width * 3 / 4 + 80, height / 2 + 100);
}


function drawSlide4_Alternativas() {
  // Slide 5: Alternativas Inteligentes e Sustentáveis
  fill(50, 100, 50);
  textSize(36);
  text("Rumo a um Futuro Mais Verde:", width / 2, 70);
  text("Alternativas Aos Agrotóxicos", width / 2, 110);

  fill(80, 80, 80);
  textSize(18);
  text("Conheça práticas que promovem uma agricultura mais saudável e equilibrada:", width / 2, 160);

  // Ícones de alternativas (exemplo)
  // Controle Biológico
  fill(255, 0, 0);
  ellipse(width / 4, height / 2 - 50, 30, 30); // Joaninha
  fill(0);
  ellipse(width / 4 - 5, height / 2 - 55, 5, 5);
  ellipse(width / 4 + 5, height / 2 - 55, 5, 5);
  textSize(16);
  text("Controle Biológico", width / 4, height / 2 + 20);
  text("(predadores naturais)", width / 4, height / 2 + 40);

  // Rotação de Culturas
  fill(100, 150, 80);
  rect(width / 2, height / 2 - 50, 40, 40, 5); // Simbolo de campo
  fill(150, 80, 100);
  rect(width / 2 + 30, height / 2 - 20, 40, 40, 5); // Simbolo de outro campo
  fill(0);
  text("Rotação de Culturas", width / 2, height / 2 + 20);
  text("(melhora o solo)", width / 2, height / 2 + 40);

  // Adubação Verde
  fill(80, 180, 80);
  rect(width * 3 / 4, height / 2 - 50, 40, 40, 5); // Simbolo de planta
  fill(120, 80, 50);
  rect(width * 3 / 4, height / 2 - 10, 50, 10, 5); // Simbolo de terra
  fill(0);
  text("Adubação Verde", width * 3 / 4, height / 2 + 20);
  text("(nutre a terra)", width * 3 / 4, height / 2 + 40);

  // Você pode adicionar mais alternativas com ícones criativos!
}

function drawSlide5_Conclusao() {
  // Slide 6: Conclusão - Colhendo Consciência
  fill(50, 100, 50);
  textSize(40);
  text("Do Campo à Cidade:", width / 2, height / 4 - 30);
  text("Colhendo Oportunidades e Consciência", width / 2, height / 4 + 30);

  fill(80, 80, 80);
  textSize(20);
  text("Faça escolhas conscientes para um futuro mais saudável e sustentável.", width / 2, height / 2);

  // Ilustração conectando campo e cidade (simplificado)
  fill(120, 200, 120); // Campo
  rect(width / 4, height * 0.75, width / 2, height * 0.3);

  fill(150, 150, 150); // Cidade
  rect(width * 3 / 4, height * 0.75, width / 2, height * 0.3);
  rect(width * 3 / 4 + 50, height * 0.75 - 50, 30, 80); // Prédio
  rect(width * 3 / 4 - 50, height * 0.75 - 30, 30, 60); // Outro prédio

  fill(255, 180, 0); // Sol
  ellipse(width - 100, 100, 80, 80);

  // Texto para QR Code ou link
  textSize(16);
  fill(0, 0, 150);
  text("Acesse o site do Agrinho para mais informações!", width / 2, height - 100);
  text("www.agrinho.com.br", width / 2, height - 70); // Coloque o URL real do Agrinho
}

// --- Funções de Navegação e Interatividade ---

function drawNavigationButtons() {
  // Botão "Próximo"
  drawButton(buttonNext.x, buttonNext.y, buttonNext.width, buttonNext.height, buttonNext.text, (currentSlide < 5));

  // Botão "Voltar" (só aparece se não for o primeiro slide)
  if (currentSlide > 0) {
    drawButton(buttonBack.x, buttonBack.y, buttonBack.width, buttonBack.height, buttonBack.text, true);
  }
}

function drawButton(x, y, w, h, label, isEnabled) {
  push();
  if (isEnabled) {
    // Muda a cor ao passar o mouse
    if (mouseX > x - w / 2 && mouseX < x + w / 2 && mouseY > y - h / 2 && mouseY < y + h / 2) {
      fill(50, 180, 50); // Cor mais clara ao passar o mouse
    } else {
      fill(0, 150, 0); // Cor normal
    }
    cursor(ARROW); // Cursor padrão
  } else {
    fill(150, 150, 150); // Cor de botão desabilitado
    cursor(NOT_ALLOWED); // Cursor de "não permitido"
  }

  rect(x, y, w, h, 10); // Botão com cantos arredondados
  fill(255); // Cor do texto
  textSize(20);
  text(label, x, y);
  pop();
}


function mousePressed() {
  // Lógica para o botão "Próximo"
  if (currentSlide < 5 && mouseX > buttonNext.x - buttonNext.width / 2 && mouseX < buttonNext.x + buttonNext.width / 2 && mouseY > buttonNext.y - buttonNext.height / 2 && mouseY < buttonNext.y + buttonNext.height / 2) {
    currentSlide++;
  }

  // Lógica para o botão "Voltar"
  if (currentSlide > 0 && mouseX > buttonBack.x - buttonBack.width / 2 && mouseX < buttonBack.x + buttonBack.width / 2 && mouseY > buttonBack.y - buttonBack.height / 2 && mouseY < buttonBack.y + buttonBack.height / 2) {
    currentSlide--;
  }

  // --- Adicione aqui a lógica de clique para elementos interativos dentro dos slides ---
  // Exemplo para o slide 1: Clique em um ícone de praga para mostrar detalhes
  // if (currentSlide === 1) {
  //   if (dist(mouseX, mouseY, x_praga_1, y_praga_1) < raio_praga_1) {
  //     // Mostrar texto ou animação da praga 1
  //   }
  // }
}